package com.creatorstudio.app.data.export

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.*
import com.creatorstudio.app.domain.model.VideoClip
import java.io.File
import java.io.FileInputStream

@OptIn(UnstableApi::class)
class VideoExportEngine(private val context: Context) {
    fun exportVideoClip(
        clip: VideoClip,
        onProgress: (Int) -> Unit,
        onComplete: (Uri) -> Unit,
        onError: (Throwable) -> Unit
    ) {
        try {
            val outputDir = File(context.cacheDir, "exports").apply { if (!exists()) mkdirs() }
            val outputFile = File(outputDir, "creator_studio_${System.currentTimeMillis()}.mp4")

            val clippingConfiguration = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(clip.startTrimMs)
                .setEndPositionMs(clip.endTrimMs)
                .build()

            val mediaItem = MediaItem.Builder()
                .setUri(clip.uri)
                .setClippingConfiguration(clippingConfiguration)
                .build()

            val editedMediaItem = EditedMediaItem.Builder(mediaItem)
                .setRemoveAudio(clip.volume == 0f)
                .build()

            val transformerListener = object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    val savedUri = saveToGallery(outputFile)
                    onComplete(savedUri ?: Uri.fromFile(outputFile))
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    onError(exportException)
                }
            }

            val transformer = Transformer.Builder(context)
                .addListener(transformerListener)
                .build()

            transformer.start(editedMediaItem, outputFile.absolutePath)
        } catch (e: Exception) {
            onError(e)
        }
    }

    private fun saveToGallery(file: File): Uri? {
        val resolver = context.contentResolver
        val contentValues = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/CreatorStudio")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues) ?: return null
        try {
            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(file).use { input -> input.copyTo(out) }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, contentValues, null, null)
            }
            return uri
        } catch (e: Exception) {
            return null
        }
    }
}
