package com.creatorstudio.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.creatorstudio.app.domain.model.StudioTool
import com.creatorstudio.app.ui.audio.AudioToolsScreen
import com.creatorstudio.app.ui.collage.CollageMakerScreen
import com.creatorstudio.app.ui.home.HomeScreen
import com.creatorstudio.app.ui.photo.PhotoEditorScreen
import com.creatorstudio.app.ui.theme.CreatorStudioTheme
import com.creatorstudio.app.ui.theme.PrimaryIndigo
import com.creatorstudio.app.ui.theme.StudioCard
import com.creatorstudio.app.ui.theme.StudioDark
import com.creatorstudio.app.ui.theme.TextMuted
import com.creatorstudio.app.ui.thumbnail.ThumbnailMakerScreen
import com.creatorstudio.app.ui.video.VideoEditorScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CreatorStudioTheme {
                var currentTool by remember { mutableStateOf(StudioTool.HOME) }

                Scaffold(
                    containerColor = StudioDark,
                    bottomBar = {
                        NavigationBar(
                            containerColor = StudioCard
                        ) {
                            NavigationBarItem(
                                selected = currentTool == StudioTool.HOME,
                                onClick = { currentTool = StudioTool.HOME },
                                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                label = { Text("Home") }
                            )
                            NavigationBarItem(
                                selected = currentTool == StudioTool.VIDEO,
                                onClick = { currentTool = StudioTool.VIDEO },
                                icon = { Icon(Icons.Default.Movie, contentDescription = "Video") },
                                label = { Text("Video") }
                            )
                            NavigationBarItem(
                                selected = currentTool == StudioTool.PHOTO,
                                onClick = { currentTool = StudioTool.PHOTO },
                                icon = { Icon(Icons.Default.Crop, contentDescription = "Photo") },
                                label = { Text("Photo") }
                            )
                            NavigationBarItem(
                                selected = currentTool == StudioTool.THUMBNAIL,
                                onClick = { currentTool = StudioTool.THUMBNAIL },
                                icon = { Icon(Icons.Default.ViewCarousel, contentDescription = "Design") },
                                label = { Text("Design") }
                            )
                            NavigationBarItem(
                                selected = currentTool == StudioTool.AUDIO,
                                onClick = { currentTool = StudioTool.AUDIO },
                                icon = { Icon(Icons.Default.Mic, contentDescription = "Audio") },
                                label = { Text("Audio") }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                        when (currentTool) {
                            StudioTool.HOME -> HomeScreen(onNavigateTo = { currentTool = it })
                            StudioTool.VIDEO -> VideoEditorScreen(onBack = { currentTool = StudioTool.HOME })
                            StudioTool.PHOTO -> PhotoEditorScreen(onBack = { currentTool = StudioTool.HOME })
                            StudioTool.THUMBNAIL -> ThumbnailMakerScreen(onBack = { currentTool = StudioTool.HOME })
                            StudioTool.COLLAGE -> CollageMakerScreen(onBack = { currentTool = StudioTool.HOME })
                            StudioTool.AUDIO -> AudioToolsScreen(onBack = { currentTool = StudioTool.HOME })
                        }
                    }
                }
            }
        }
    }
}
